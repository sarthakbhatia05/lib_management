let model_schema = "myLibrary"

module.exports = model_schema