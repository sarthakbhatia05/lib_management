const myLibrary = require('../model/books-schema')
const newBookSchema = require('../db/new-book-schema')

module.exports = {

  addNewBook: async (req, res) => {
    try {
      if (req.body.length === 1) {
        // const newBook = new myLibrary({
        //   bookName: req.body.bookName,
        //   author: req.body.author,
        //   yearPublished: req.body.yearPublished,
        //   category: req.body.category

        // })
        const newBook = newBookSchema(req)
        const result = await newBook.save()
        console.log(result)
        res.send(req.body.length)
      }
      else {
        const reqTemp = req.body
        const result = await myLibrary.insertMany(reqTemp)
        console.log(result)
        res.json(result)
      }
    } catch (err) {
      res.send('Book Already Exists')
      console.log(err)
    }
  },

  showAllBooks: async (req, res) => {
    try {
      const result = await myLibrary.find()
      res.send(result)
    } catch (err) {
      console.log(err)
    }

  },
  showBookByName: async (req, res) => {
    try {
      const bookRef = req.params.name
      const result = await myLibrary.find({ bookName: bookRef })
      res.send(result)
    } catch (err) {
      console.log(err)
    }
  },

  deleteBook: async (req, res) => {
    try {
      const bookRef = req.params.name
      const result = await myLibrary.deleteOne({ name: bookRef })
      res.send(result)
    } catch (err) {
      console.log(err)
    }
  },
  deleteAll: async (req, res) => {
    try {
      const result = await myLibrary.deleteMany({})
      res.send(result)

    } catch (err) {
      console.log(err)
    }
  },
  updateByName: async (req, res) => {
    try {
      const bookRef = req.param.name
      const result = await myLibrary.updateOne({ name: bookRef }, {
        $set: {
          bookName: req.body.bookName,
          author: req.body.author,
          yearPublished: req.body.yearPublished,
          category: req.body.category
        }
      })
      res.json(result)
      console.log(result)
    } catch (err) {
      console.log(err)
    }
  }
}