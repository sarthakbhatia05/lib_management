const express = require('express')
const controller = require('../controllers/library-controller')

const router = express.Router()

router.post('/addnewbook', controller.addNewBook)
router.get('/showallbooks', controller.showAllBooks)
router.get('/showbookbyname/:name', controller.showBookByName)
router.post('/updatebyname/:name', controller.updateByName)
router.post('/deletebook/:name', controller.deleteBook)
router.post('/deleteall', controller.deleteAll)

module.exports = router
