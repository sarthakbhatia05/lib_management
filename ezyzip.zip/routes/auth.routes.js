const express = require('express')
const router_auth = express.Router()

router_auth.post('/register',async(req,res,next)=>{
    res.send('registeration route')
})

router_auth.post('/login',async(req,res,next)=>{
    res.send('Login route')
})




module.exports = router_auth