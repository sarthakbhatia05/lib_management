const request = require('supertest')
const app = require('../routes/library-routes')

describe("GET /showallbooks", () => {
    test("Testing to get all books", async () => {
        jest.setTimeout(async () => {
            const allBooks = await request(app).get("/showallbooks");
            expect(allBooks.body.success).toEqual(true);
            expect(allBooks.statusCode).toEqual(200);
            expect(allBooks.body.data[0]).toHaveProperty("bookName", "author");
        }, 3000);
    });
});

describe("GET /showbookbyname/:name", () => {
    test("Testing for getting book by id", async () => {
        jest.setTimeout(async () => {
            const book = await request(app).get("/showbookbyname/:name")
            expect(book.body.success).toEqual(true)
            expect(book.statusCode).toEqual(200)

        }, 3000)

    });
});

describe("POST /addnewbook", () => {
    test("Testing to add new book", async () => {
        jest.setTimeout(async () => {
            const newBook = await request(app).post("/addnewbook")
            expect(newBook.body.success).toEqual(true);
            expect(newBook.statusCode).toEqual(201);
        }, 3000)

    });

});

describe("POST /deletebook/:name", () => {
    test("Testing to delete book by name", async () => {
        jest.setTimeout(async () => {
            const deleteBook = await request(app).post("/deletebook/:name")
            expect(deleteBook.body.success).toEqual(true);
            expect(deleteBook.statusCode).toEqual(201);
        }, 3000)

    });

});

describe("POST /deleteall", () => {
    test("Testing to delete all books", async () => {
        jest.setTimeout(async () => {
            const deleteBooks = await request(app).post("/deleteall")
            expect(deleteBooks.body.success).toEqual(true);
            expect(deleteBooks.statusCode).toEqual(201);
        }, 3000)

    });

});

describe("POST /updatebyname/:name", () => {
    test("Testing to delete book by name", async () => {
        jest.setTimeout(async () => {
            const updateBook = await request(app).post("/updatebyname/:name")
            expect(updateBook.body.success).toEqual(true);
            expect(updateBook.statusCode).toEqual(201);
        }, 3000)

    });

});


