const mongoose = require('mongoose')
const MyLibrary = require('../constant-strings')
const bookSchema = new mongoose.Schema({
    bookName: {
        type: String,
        required: true,
        unique :[true,"Book Already Exists"]
    },
    author: String,
    yearPublished:Number,
    category : String
})

const myLibrary = new mongoose.model(MyLibrary, bookSchema)

module.exports = myLibrary