const express = require('express')
const app = express()
app.use(express.json()) 
app.use(express.urlencoded({extended:true}))

const routes = require('./routes/library-routes')

const dotenv = require('dotenv')
dotenv.config({ path:'./config.env' })

const PORT = process.env.PORT;
const db = process.env.DATABASE_LOCAL

const mongoose = require('mongoose')


mongoose.set('strictQuery', true)

mongoose
    .connect(db)
    .then(() => {
        console.log('database connected')
    })
    .catch((err) => {
        console.log(err.message)
    })

app.use('/',routes)


app.listen(PORT,() =>{
    console.log(`Server is running at Port ${PORT}`)
})