const myLibrary = require('../model/books-schema')

function newBookSchema(req) {
  const newBook = new myLibrary({
    bookName: req.body.bookName,
    author: req.body.author,
    yearPublished: req.body.yearPublished,
    category: req.body.category,

  })
  return newBook
}

module.exports = newBookSchema()
